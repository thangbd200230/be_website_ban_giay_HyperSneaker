package com.spring.shop.response;

public interface TKTuan {
	Integer getSoSanPham();

	Integer getSoLuongHuy();

	Integer getSoLuongThanhCong();

	Double getDoanhThu();
}
