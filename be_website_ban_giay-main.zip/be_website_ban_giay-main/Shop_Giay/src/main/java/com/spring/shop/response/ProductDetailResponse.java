package com.spring.shop.response;

public interface ProductDetailResponse {
    Integer getId();
    Integer getIdProductDetail();
    Integer getIdColor();
    Integer getIdSize();
    Integer getQuantity();
}
