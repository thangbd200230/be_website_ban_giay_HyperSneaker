package com.spring.shop.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RoleRequest {
    
    private String Name;

    private Integer Status;

}
