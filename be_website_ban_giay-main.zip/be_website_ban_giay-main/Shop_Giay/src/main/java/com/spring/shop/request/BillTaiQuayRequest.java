package com.spring.shop.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BillTaiQuayRequest {
    private Integer IdEmployee;
    private Integer Status;
    private Integer TypeStatus;

}
