package com.spring.shop.response;

public interface TKSanPham {
    String getUrl();
    String getName();
    Integer getSoLuong();
    Double getDoanhThu();
}
