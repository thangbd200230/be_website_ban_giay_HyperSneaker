package com.spring.shop.response;

public interface TKSoLuongSanPham {
    String getPurchaseDay();
    Integer getSoLuong();
    Double getDoanhThu();

}
