package com.spring.shop.response;

public interface TKNam {
	Integer getSoSanPham();

	Integer getSoLuongHuy();

	Integer getSoLuongThanhCong();

	Double getDoanhThu();
}
