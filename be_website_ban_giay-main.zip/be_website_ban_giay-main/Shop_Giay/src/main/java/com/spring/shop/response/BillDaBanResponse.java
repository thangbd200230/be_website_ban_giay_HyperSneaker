package com.spring.shop.response;

public interface BillDaBanResponse {
    Integer getIdColor();
    Integer getIdSize();
    Integer getQuantity();
    Double getPrice();
}
