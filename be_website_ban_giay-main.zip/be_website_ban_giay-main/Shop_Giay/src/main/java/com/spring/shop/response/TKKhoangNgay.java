package com.spring.shop.response;

import java.util.Date;

public interface TKKhoangNgay {
	Integer getSoSanPham();

	Integer getSoLuongHuy();

	Integer getSoLuongThanhCong();

	Double getDoanhThu();
}
