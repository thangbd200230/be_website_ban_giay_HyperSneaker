package com.spring.shop.response;

public interface TKSLThang {
    Integer getSoLuong();
}
