package com.spring.shop.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductDetail_MaterialRequest {
    private Integer IdProductDetail;
    private Integer IdMaterial;
}
