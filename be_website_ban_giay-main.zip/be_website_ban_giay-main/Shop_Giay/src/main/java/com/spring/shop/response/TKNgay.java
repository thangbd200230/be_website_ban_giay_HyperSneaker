package com.spring.shop.response;

public interface TKNgay {
	Integer getSoSanPham();

	Integer getSoLuongHuy();

	Integer getSoLuongThanhCong();

	Double getDoanhThu();
}
